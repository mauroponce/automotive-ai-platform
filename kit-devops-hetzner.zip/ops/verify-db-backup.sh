#!/usr/bin/env bash
set -Eeuo pipefail
[[ $# -eq 1 ]] || { echo "Uso: bash ops/verify-db-backup.sh RUTA.dump" >&2; exit 2; }
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
FILE="$1"
[[ -f "$FILE" && -s "$FILE" ]] || { echo "No existe el backup o está vacío: $FILE" >&2; exit 1; }
DIR="$(cd "$(dirname "$FILE")" && pwd)"
BASENAME="$(basename "$FILE")"
if [[ -f "$DIR/$BASENAME.sha256" ]]; then
  (cd "$DIR"
    if command -v sha256sum >/dev/null 2>&1; then
      sha256sum -c "$BASENAME.sha256"
    else
      shasum -a 256 -c "$BASENAME.sha256"
    fi
  )
fi
docker compose exec -T postgres pg_restore --list < "$FILE" > /dev/null
echo "Estructura del backup legible. IMPORTANTE: esto no reemplaza una prueba de restauración."
