#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '== Contenedores =='
docker compose ps
echo
echo '== Espacio Docker =='
docker system df
echo
echo '== Disco del host =='
df -h
echo
echo '== Memoria =='
free -h 2>/dev/null || true
