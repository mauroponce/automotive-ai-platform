# Comandos operativos para aprender DevOps

## 0. Antes de ejecutar

**Son scripts de referencia, no scripts que ya estén integrados en el repositorio.** Pedile a Codex que revise los nombres de servicios de `compose.yaml` y adapte los scripts; asumen servicios `postgres`, `web` y `worker`.

Desde la raíz del repo, en Linux/macOS/WSL:

```bash
chmod +x ops/*.sh
bash ops/status.sh
```

`docker compose` usa por defecto la configuración local. En la VPS, Codex deberá establecer la combinación de Compose correspondiente. Por ejemplo:

```bash
export COMPOSE_FILE=compose.yaml:compose.prod.yaml
```

Este ejemplo **no aplica automáticamente** si los archivos se llaman de otra manera.

## 1. Arranque, parada, reinicio y logs

```bash
# Estado
docker compose ps

# Iniciar entorno local (construye imágenes si hace falta)
docker compose up -d --build

# Ver logs generales
docker compose logs --tail=100

# Ver logs del worker en vivo
bash ops/logs.sh worker

# Reiniciar solo el worker
docker compose restart worker

# Detener contenedores manteniendo datos
docker compose stop

# Reanudar
docker compose start
```

**Importante:** `docker compose restart` no aplica nuevos cambios de la imagen. Para desplegar nuevas imágenes se usa `docker compose pull` y `docker compose up -d`; previamente revisá migraciones y versión.

## 2. Backups de PostgreSQL

`ops/backup-db.sh` utiliza `pg_dump -Fc`, de modo que genera un backup lógico en formato custom. Guarda el archivo en `backups/postgres/` (que debe ignorarse por Git), lo comprueba con `pg_restore --list` y crea checksum SHA-256.

```bash
bash ops/backup-db.sh
bash ops/verify-db-backup.sh backups/postgres/ARCHIVO.dump
```

Los dumps suelen incluir datos sensibles. Mantener permisos restringidos y cifrarlos al salir del servidor.

Para restaurar en la base configurada (¡puede borrar datos!):

```bash
# 1) Hacer un backup adicional y verificarlo.
# 2) Detener escrituras de web y worker.
docker compose stop web worker

# 3) Invocación protegida; reemplazar el nombre real.
CONFIRM_RESTORE='RESTORE_CURRENT_DATABASE' bash ops/restore-db.sh backups/postgres/ARCHIVO.dump

# 4) Reactivar web y worker solamente si la restauración terminó bien.
docker compose start web worker
```

Para una restauración **de ensayo** recomendamos crear un contenedor/PostgreSQL separado y aplicar el dump allí: no usar `restore-db.sh` contra producción para probar un backup.

### ¿Y el backup fuera del servidor?

Configurar un repositorio cifrado restic **en otro proveedor o ubicación independiente**. Crear secretos en la VPS; nunca en Git:

- `RESTIC_REPOSITORY`: repositorio de destino (p. ej., S3 externo con credenciales configuradas).
- `RESTIC_PASSWORD_FILE`: archivo con la clave de cifrado del repositorio, fuera del repo.
- Credenciales específicas del proveedor según el backend restic.

Inicializar `restic init` una vez y usar:

```bash
bash ops/backup-db.sh
bash ops/offsite-db.sh backups/postgres/ARCHIVO.dump
restic snapshots
restic check
# Revisar política de retención ANTES de borrar nada:
restic forget --keep-daily 7 --keep-weekly 4 --keep-monthly 6 --dry-run
```

No se automatiza `restic forget --prune` hasta que la restauración y retención estén probadas.

**Atención:** dejar backups locales en la VPS no es suficiente ante pérdida del disco o de la cuenta.

## 3. Copias de fotografías (Object Storage)

`pg_dump` guarda metadatos y referencias de archivos, **no** los bytes de las fotografías. Antes de activar el backup de fotos, configurar con `rclone config` un remoto origen (bucket con las fotos) y otro destino independiente, idealmente un remoto `crypt`.

Variables:

```bash
export MEDIA_SOURCE_REMOTE='fotos-origen:bucket-fotos'
export MEDIA_BACKUP_REMOTE='fotos-externas-cifradas:backup-fotos'
bash ops/backup-media.sh
```

El script usa `rclone copy`: **no borra** archivos del destino. Ejecutar copias periódicas y verificar integridad y restauración; documentar política de retención y consistencia con PostgreSQL.

## 4. Espacio Docker

```bash
docker system df
docker image ls
docker volume ls
df -h

# Solo imágenes colgantes viejas y caché de compilación vieja
bash ops/docker-clean-safe.sh
```

El comando `docker image prune -a` elimina también imágenes etiquetadas que ningún contenedor está usando: podría eliminar versiones guardadas para rollback. **No** lo programes automáticamente sin una política de retención.

No automatices `docker system prune -a --volumes` ni `docker compose down -v`.

## 5. Actualizaciones, deploy y rollback

En el futuro, el workflow de GitHub Actions debe generar `web:<commit_sha>` y `worker:<commit_sha>` en GHCR. Los comandos exactos dependen del Compose real:

```bash
# Consultar versión desplegada
docker compose images

# Tras tests, backups y revisión de migraciones:
docker compose pull web worker
docker compose up -d --no-build web worker

# Salud y logs
docker compose ps
docker compose logs --tail=100 web worker
```

Para rollback, modificar `IMAGE_TAG` (u otra variable que decida Codex) al SHA anterior y ejecutar `docker compose pull && docker compose up -d --no-build`. **Advertencia:** volver atrás en imágenes no revierte migraciones de base de datos; planificar migraciones compatibles antes de actualizar.

No usar etiquetas `latest` como único identificador de despliegue.

## 6. Diagnóstico rápido

```bash
bash ops/status.sh
bash ops/logs.sh web
bash ops/logs.sh worker

docker compose exec -T postgres sh -c 'pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB"'

docker stats --no-stream
docker system df
df -h
```

## 7. Seguridad y conservación

- Nunca subir `.env`, credenciales, dumps o archivos de clientes a GitHub.
- Incorporar las líneas de `ops/gitignore-additions.txt` al `.gitignore` existente.
- No exponer PostgreSQL a Internet.
- No ejecutar scripts de limpieza sobre una VPS que tenga otros proyectos sin revisar el efecto global de los comandos Docker: `docker image prune` y `docker builder prune` afectan todo el host.
- Todos los ejemplos de backup/restore usan nombres de servicios genéricos. Revisar antes de usarlos con información real.
