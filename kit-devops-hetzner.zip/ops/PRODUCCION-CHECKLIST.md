# Checklist antes de activar producción en Hetzner

Esta lista **no implica que esté hecho**. Marcar cada punto luego de comprobarlo.

- [ ] VPS creada con SSH por llave y usuario separado.
- [ ] SSH restringido; firewall activo; sólo puertos necesarios.
- [ ] Docker Compose de producción revisado (sin puertos públicos para PostgreSQL).
- [ ] Servicios `web`, `worker`, `postgres`, `caddy` con healthchecks.
- [ ] Caddy emite certificados HTTPS válidos.
- [ ] Los secretos están fuera del repositorio; permisos mínimos.
- [ ] Bucket privado Hetzner Object Storage, accesos mínimos, URLs firmadas.
- [ ] Backup PostgreSQL automático probado con restore en entorno de prueba.
- [ ] Dumps PostgreSQL copiados cifrados a destino fuera de la VPS.
- [ ] Fotografías (bucket) respaldadas en destino independiente y recuperables.
- [ ] Retención definida y probada (p. ej. 7 diarios, 4 semanales, 6 mensuales).
- [ ] Alertas de backup fallido, disco lleno y servicios caídos.
- [ ] Logs rotados y monitoreados (evitar crecer sin límite).
- [ ] GitHub Actions construye imágenes con SHA, guarda en GHCR y despliega con aprobación.
- [ ] Rollback de contenedores ensayado; migraciones compatibles con rollback.
- [ ] Nunca ejecutar `docker compose down -v` ni podar volúmenes en producción.
- [ ] Política de actualización de sistema operativo, Docker y dependencias.
- [ ] Política de privacidad y tiempo de retención de fotos de vehículos.
