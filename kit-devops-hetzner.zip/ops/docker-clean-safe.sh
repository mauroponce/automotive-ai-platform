#!/usr/bin/env bash
# Limpieza conservadora: NO toca contenedores, volúmenes ni imágenes etiquetadas.
set -Eeuo pipefail
echo 'Uso actual de Docker:'
docker system df
echo
echo 'Eliminando únicamente imágenes dangling con más de 7 días...'
docker image prune --force --filter 'until=168h'
echo 'Eliminando caché de compilación no usada con más de 7 días...'
docker builder prune --force --filter 'until=168h'
echo 'Uso final de Docker:'
docker system df
echo 'No se borraron volúmenes. Revisá siempre el uso en hosts compartidos.'
