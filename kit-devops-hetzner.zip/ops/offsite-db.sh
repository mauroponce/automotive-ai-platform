#!/usr/bin/env bash
# Copia un dump PostgreSQL hacia un repositorio restic remoto cifrado, ya inicializado.
set -Eeuo pipefail
[[ $# -eq 1 ]] || { echo 'Uso: bash ops/offsite-db.sh RUTA.dump' >&2; exit 2; }
[[ -n "${RESTIC_REPOSITORY:-}" && -n "${RESTIC_PASSWORD_FILE:-}" ]] || { echo 'Configurar RESTIC_REPOSITORY y RESTIC_PASSWORD_FILE fuera de Git.' >&2; exit 2; }
command -v restic >/dev/null || { echo 'Falta instalar restic.' >&2; exit 2; }
FILE="$1"
[[ -f "$FILE" && -s "$FILE" ]] || { echo "Archivo inválido: $FILE" >&2; exit 2; }
restic backup --tag postgres "$FILE"
echo 'Backup enviado al repositorio restic. Verificar snapshots y restauraciones regularmente.'
