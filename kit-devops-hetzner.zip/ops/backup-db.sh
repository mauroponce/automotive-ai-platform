#!/usr/bin/env bash
# Backup lógico de PostgreSQL del servicio docker compose 'postgres'.
# Se verifica el archivo antes de considerarlo exitoso.
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
BACKUP_DIR="${BACKUP_DIR:-$ROOT/backups/postgres}"
mkdir -p "$BACKUP_DIR"
NAME="postgres-$(date -u +%Y%m%dT%H%M%SZ).dump"
DEST="$BACKUP_DIR/$NAME"
TMP="$(mktemp "$BACKUP_DIR/.pgbackup.XXXXXX")"
trap 'rm -f "$TMP"' EXIT

echo "Exportando PostgreSQL (servicio: postgres)..."
docker compose exec -T postgres sh -c 'exec pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc --no-owner --no-acl' > "$TMP"
[[ -s "$TMP" ]] || { echo 'ERROR: backup vacío.' >&2; exit 1; }
# Verifica que el archivo pueda ser listado por pg_restore.
docker compose exec -T postgres pg_restore --list < "$TMP" > /dev/null
mv "$TMP" "$DEST"
( cd "$BACKUP_DIR"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$NAME" > "$NAME.sha256"
  else
    shasum -a 256 "$NAME" > "$NAME.sha256"
  fi
)
trap - EXIT
echo "Backup creado y verificado: $DEST"
echo "ATENCIÓN: aún falta copiarlo a un destino externo y cifrado."
