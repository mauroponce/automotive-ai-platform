#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
SERVICE="${1:-worker}"
case "$SERVICE" in
  web|worker|postgres|caddy|minio) ;;
  *) echo "Servicio no permitido: $SERVICE. Usá web, worker, postgres, caddy o minio." >&2; exit 2 ;;
esac
docker compose logs -f --tail=120 "$SERVICE"
