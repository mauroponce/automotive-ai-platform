#!/usr/bin/env bash
# Replica archivos de un bucket/remote origen hacia otro remoto independiente.
# Usa copy (NO sync), por lo que NO elimina archivos en destino.
set -Eeuo pipefail
command -v rclone >/dev/null || { echo 'Falta instalar rclone.' >&2; exit 2; }
[[ -n "${MEDIA_SOURCE_REMOTE:-}" && -n "${MEDIA_BACKUP_REMOTE:-}" ]] || { echo 'Configurar MEDIA_SOURCE_REMOTE y MEDIA_BACKUP_REMOTE.' >&2; exit 2; }
[[ "$MEDIA_SOURCE_REMOTE" != "$MEDIA_BACKUP_REMOTE" ]] || { echo 'Origen y destino deben ser distintos.' >&2; exit 2; }
# IMPORTANTE: usar en destino un remote crypt configurado y/o cifrado del proveedor.
rclone copy "$MEDIA_SOURCE_REMOTE" "$MEDIA_BACKUP_REMOTE" --checkers 4 --transfers 2 --stats 30s
printf '\nCopia terminada. Verificar integridad y recuperación regularmente.\n'
