# Prompt para pegar en Codex (ejecutar desde el repositorio REAL)

Quiero integrar esta carpeta `ops/` y `DEVOPS.md` al proyecto actual de edición autoservicio de fotografías de vehículos. Primero auditá los archivos `compose*.y*ml`, nombres reales de servicios, Dockerfiles, entorno local/producción, estrategia PostgreSQL, almacenamiento S3, GitHub Actions y despliegue. No crees una aplicación nueva ni reescribas funcionalidades de negocio.

Adaptá los scripts operativos a la configuración existente, **sin ejecutar restore, prune, cambios de producción ni comandos destructivos**. Comprobá compatibilidad con Linux y el Compose real. Documentá en `DEVOPS.md` comandos cotidianos: estado, logs, reinicio, backup/verificación/restore controlado, almacenamiento externo de PostgreSQL y fotos, espacio Docker, limpieza conservadora, despliegue/rollback y troubleshooting.

Requisitos de seguridad: backup de PostgreSQL con `pg_dump -Fc` y validación; aviso y confirmación literal para restore, comprobar que `web` y `worker` estén detenidos; los backups locales ignorados por Git; documentación de `restic` con destino cifrado e independiente y `rclone copy` para fotografías; nunca usar `docker compose down -v`, `docker volume prune` ni `docker system prune -a --volumes` en tareas automáticas. No poner secretos en Git ni logs. No asumir que backup DB cubre Object Storage.

No programes backups automáticos sin antes disponer de destino externo y pruebas de restauración. Si el código ya tiene scripts equivalentes, preferí mejorar los existentes y documentarlos, en lugar de duplicarlos. Asegurá que cualquier comando potencialmente peligroso tenga salvaguardas y ejemplos explícitos para entornos local y producción.

Agregá comandos accesibles (por ejemplo `make help`, `make status`, `make db-backup`, etc.) únicamente si el repo ya usa Makefile o resulta natural; evitá colisiones de archivos.

Ejecutá `bash -n ops/*.sh`, los tests relevantes y pruebas no destructivas de Docker si los servicios están disponibles. Entregá un resumen de archivos tocados, comandos verificados, limitaciones y lo que me falta configurar en la VPS futura. Explicá lo esencial de DevOps con comentarios claros en español para alguien que empieza.
