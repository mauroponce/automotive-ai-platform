#!/usr/bin/env bash
# Destructivo. Restauración a la base actual: requiere confirmación literal y web/worker detenidos.
set -Eeuo pipefail
[[ $# -eq 1 ]] || { echo 'Uso: CONFIRM_RESTORE=RESTORE_CURRENT_DATABASE bash ops/restore-db.sh RUTA.dump' >&2; exit 2; }
[[ "${CONFIRM_RESTORE:-}" == 'RESTORE_CURRENT_DATABASE' ]] || { echo 'BLOQUEADO: falta CONFIRM_RESTORE=RESTORE_CURRENT_DATABASE' >&2; exit 2; }
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
FILE="$1"
[[ -f "$FILE" && -s "$FILE" ]] || { echo "Backup inválido: $FILE" >&2; exit 1; }
# Evitamos escrituras concurrentes y minimizamos restauraciones accidentales.
RUNNING="$(docker compose ps --status running --services)"
if printf '%s\n' "$RUNNING" | grep -Eq '^(web|worker)$'; then
  echo 'BLOQUEADO: detené web y worker con docker compose stop web worker.' >&2
  exit 2
fi
echo 'ADVERTENCIA: se reemplazarán objetos y datos de la base PostgreSQL actualmente configurada.'
echo 'Confirmación explícita recibida. Validando dump...'
docker compose exec -T postgres pg_restore --list < "$FILE" > /dev/null
docker compose exec -T postgres sh -c 'exec pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists --single-transaction --exit-on-error --no-owner --no-acl' < "$FILE"
echo 'Restauración concluida. Revisar aplicación antes de iniciar web/worker.'
