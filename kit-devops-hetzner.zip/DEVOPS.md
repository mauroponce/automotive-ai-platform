# Manual de DevOps — SaaS de imágenes de vehículos

Este documento es un **punto de partida**. Los scripts deben ser revisados por Codex contra los nombres reales de servicios y la estructura del repositorio antes de usarse en producción.

## ¿Qué administra cada pieza?

- **Docker:** ejecuta aplicaciones dentro de contenedores.
- **Docker Compose:** define servicios (`web`, `worker`, `postgres`, y `minio` local), redes y volúmenes.
- **Imagen Docker:** paquete inmutable de código y dependencias. No es una foto de un vehículo.
- **Volumen:** datos persistentes; aquí vive PostgreSQL. **No se borra al limpiar imágenes.**
- **GHCR:** registro que guarda las imágenes Docker versionadas.
- **Hetzner Object Storage:** guarda originales y resultados de fotografías; es independiente de PostgreSQL.
- **Backup:** copia recuperable, preferentemente cifrada y almacenada fuera de la VPS.

## Primeros comandos (desde la raíz del repositorio)

```bash
# Ver servicios y su estado
docker compose ps

# Iniciar el ambiente local
docker compose up -d --build

# Seguir logs de la web y el procesador
docker compose logs -f --tail=100 web worker

# Reiniciar solamente la web
docker compose restart web

# Ver cuánto ocupa Docker
docker system df

# Backup completo lógico de PostgreSQL (el script crea un archivo .dump)
bash ops/backup-db.sh

# Limpiar únicamente imágenes colgantes viejas y caché vieja
bash ops/docker-clean-safe.sh
```

> **En producción**, usá el `COMPOSE_FILE` definido para el servidor, por ejemplo `COMPOSE_FILE=compose.yaml:compose.prod.yaml`, *solo si Codex valida que esos archivos sean los correctos*. Nunca ejecutes contra el servidor equivocado por descuido.

## Operación habitual

| Necesito… | Comando | ¿Modifica datos? |
|---|---|---|
| Ver si están vivos | `bash ops/status.sh` | No |
| Seguir errores | `bash ops/logs.sh worker` | No |
| Ver espacio | `docker system df && df -h` | No |
| Guardar PostgreSQL | `bash ops/backup-db.sh` | Crea backup |
| Comprobar un backup | `bash ops/verify-db-backup.sh RUTA.dump` | No |
| Limpiar sin tocar volúmenes | `bash ops/docker-clean-safe.sh` | Borra caché / imágenes colgantes viejas |
| Restaurar base de datos | `bash ops/restore-db.sh RUTA.dump` | **Sí, destructivo**; requiere confirmación y detener web/worker |
| Copiar backups fuera del servidor | `bash ops/offsite-db.sh RUTA.dump` | Copia a repositorio restic configurado |
| Respaldar fotos del bucket | `bash ops/backup-media.sh` | Copia objetos con rclone; no borra origen ni destino |

## Operaciones que **no** se hacen a ciegas

```bash
# PELIGRO: puede borrar datos persistentes si combinás opciones/volúmenes
# docker compose down -v
# docker volume prune -a
# docker system prune -a --volumes
# docker rm -f ...
# rm -rf /var/lib/docker
```

`docker compose down` **sin** `-v` preserva los volúmenes nombrados, pero detiene el sistema. Para despliegues normales preferir `docker compose up -d`.

## Plan de mantenimiento orientativo

- **Todos los días, cuando exista producción:** comprobar que el backup de PostgreSQL se hizo y se copió a un destino externo. Usar el scheduler del servidor (systemd timer) solo después de probarlo.
- **Semanalmente:** verificar logs, espacio disponible, fallos del worker y backups de fotografías.
- **Mensualmente:** restaurar un backup en una base **de prueba**, revisar seguridad, actualizaciones y costes. Verificar el almacenamiento externo con `restic check`.
- **En cada deploy:** tests, imágenes versionadas, migraciones revisadas, healthchecks y posibilidad de volver a la imagen anterior.

## Antes de exponer la VPS a internet

1. Acceso SSH por llave, deshabilitar autenticación por contraseña cuando esté comprobada la llave.
2. Firewall: exponer 80/443 y restringir SSH; **no exponer PostgreSQL ni MinIO**.
3. Caddy y HTTPS; secretos fuera de Git y permisos mínimos.
4. Limitar acceso Docker/SSH (el grupo docker equivale prácticamente a privilegios de root).
5. Backups cifrados fuera del servidor y una restauración probada.
6. Logs del worker con rotación, monitorización y alertas por disco/servicios caídos.
7. Permisos de acceso a buckets privados y credenciales de mínima capacidad.
8. Para base de datos y fotos: respaldos distintos. Un `pg_dump` **no** incluye archivos del bucket.

Más detalles y ejemplos: `ops/README.md`.
